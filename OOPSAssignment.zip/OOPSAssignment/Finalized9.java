/*  With the help of finalize method print the how many objects are currently 
a class is having and which object is going to be freed from the memory 
with its hashcode.  */
package OOPSAssignment;



public class Finalized9 {

	 private int x;
	    public static void main(String[] args) {
	    	Finalized9  a=new Finalized9 ();
	    	Finalized9  a1=new Finalized9 ();
	    	Finalized9  a2=new Finalized9 ();
	        a.x=10;
	        System.out.println(a.x);
	        System.out.println(a1.hashCode());
	        a1=null;
	        
	        System.out.println(a.hashCode()+"of a");
	        System.out.println(a2.hashCode()+"of a2");
	        a.finalize();
	        
	        System.out.println(a.hashCode());
	        System.gc();
	        
	    }
	    @Override
	    protected void finalize() {
	        System.out.println("in finalize");
	        
	    }



	}