package OOPSAssignment5;

 public class C extends B{



	   
    @Override
    void mul(int a, int b) {
System.out.println(a*b);        super.mul(a, b);
    }
    
    public static void main(String[] args) {
        
        A a = new A();
        B b = new B();
        C c = new C();
        D d = new D();
        a.sum(10, 10);
        b.sub(20, 10);
        c.mul(2, 2);
        d.div(40, 4);
        
    }
}