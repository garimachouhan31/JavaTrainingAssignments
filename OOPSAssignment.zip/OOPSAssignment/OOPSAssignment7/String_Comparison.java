package OOPSAssignment7;

public class String_Comparison {
    String s1;
    public boolean equals(Object obj)
    {
        String_Comparison s = (String_Comparison) obj;
        
        if(s1!=s.s1)
        {
            return false;
        }
        return true;
        
    }



       String_Comparison(String s1)
        {
            this.s1 = s1;
        
            
        }



       
        
}
