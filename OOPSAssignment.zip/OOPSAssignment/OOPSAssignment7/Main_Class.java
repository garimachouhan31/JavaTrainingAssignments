package OOPSAssignment7;

import java.util.Scanner;



public class Main_Class{
    



   public static void main(String[] args) {
        Scanner scx = new Scanner(System.in);
        System.out.println("Enter First String");
        String sc = scx.nextLine();
        System.out.println("Enter Second String");



       String sc1 = scx.nextLine();
        
        //String_Comparison sc = new String_Comparison("kushal");
        //String_Comparison sc1 = new String_Comparison("kushal");
        if (sc.equals(sc1)) {
            System.out.println("Equal ");
        } else {
            System.out.println("Not Equal ");
        }
        
    }



}