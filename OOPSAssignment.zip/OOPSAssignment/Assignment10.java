/*WAP to demonstrate the use of clone method. Clone one object of 
Product class :- pid, pname, price and unitOfMeasurement. When you 
clone object of class Product change the product name and price. With 
the help of instanceOf check that the newly created object is belong to 
Product class or not.*/


package OOPSAssignment;

import javax.naming.ldap.PagedResultsControl;



public class Assignment10 implements Cloneable {
    
    
    int pid;
    String pname;
    int price;
    Double Unit;
    
    
    
    protected Assignment10(int pid, String pname, int price, Double unit) {
        super();
        this.pid = pid;
        this.pname = pname;
        this.price = price;
        Unit = unit;
    }




    public Object clone()throws CloneNotSupportedException{  
        return super.clone();  
        }  
          
    
    public static void main(String[] args) {
    try {    
    	Assignment10 p = new Assignment10(132465, "Miphone", 42000, 25.6);

     System.out.println(p.pid + " " +p.pname+" "+ p.price+ " " +p.Unit);
     
     Assignment10 pclone = (Assignment10) p.clone();
    pclone.pname="OPPO";
    pclone.price=24000;
    System.out.println(pclone.pid + " " +pclone.pname+" "+ pclone.price+ " " +pclone.Unit);
    }    catch(CloneNotSupportedException c){}
    }



}