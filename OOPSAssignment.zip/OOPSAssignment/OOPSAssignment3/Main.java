package OOPSAssignment3;

public class Main {
    public static void main(String[] args)
     {
         System.out.println("<--<--branch details-->-->");
         
         Branch   b1 = new Branch(111,"IDBI"," Indore" );
       
         
         System.out.println("details of brnach b1");
         System.out.println(b1);
         
         Branch   b2 = new Branch(112,"HDFC","Barwaha" );
         System.out.println("details of brnach b2");
         System.out.println(b2);
         
         Branch   b3 = new Branch(113,"IDFC","Sanawad" );
         System.out.println("details of brnach b3");
         System.out.println(b3);
         
       System.out.println("<--<--customer details-->-->");    
       
       Customer c1 = new Customer(121,0001,"Garima", "Barwaha","15/11/91","12/12/21", b1);
       System.out.println("details of customer c1");
       System.out.println(c1);
       
       Customer c2 = new Customer(122,0002,"Gourav", "Sanawad","07/07/91","01/12/22", b2);
       System.out.println("details of customer c2");
       System.out.println(c2);
       
       Customer c3 = new Customer(133,0002,"Rahul", "Indore","05/03/95","01/02/20", b3);
       System.out.println("details of customer c3");
       System.out.println(c3);
       
       
       System.out.println("<--<--all the details of Customer_Account_Statement-->-->");
       
       Customer_account_Statement ca1 = new Customer_account_Statement(201,c1, 1000, 100, "05/08/2022");
       System.out.println("details of Customer_Account_Statement ca1");
       System.out.println(ca1);
       
       Customer_account_Statement ca2 = new Customer_account_Statement(202,c2, 60000, 300, "17/07/2022");
       System.out.println("details of Customer_Account_Statement ca2");
       System.out.println(ca2);
       
       Customer_account_Statement ca3 = new Customer_account_Statement(203,c3, 3000, 150, "21/07/2022");
       System.out.println("details of Customer_Account_Statement ca3");
       System.out.println(ca3);
     }



}