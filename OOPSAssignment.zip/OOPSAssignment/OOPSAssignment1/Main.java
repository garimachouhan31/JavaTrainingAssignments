package OOPSAssignment1;

import java.time.LocalDate;



public class Main {



   public static void main(String[] args) {
        



       
        
        Customer cust = new Customer(0, null, null, null, null, null, 0, null);
        
        Department[] dept=new Department[10];
        
        Department d1=new Department(101,"IT");
        Department d2=new Department(102,"CS");
        
        dept[0]=d1;
        dept[1]=d2;
        
        Employee emp=new Employee(1,"Justin Yohannan","Lavkush", LocalDate.of(1998,03,24) ,1000.00, LocalDate.of(2022,03,24), "Indore", dept[0], 14111, "justin@gmail.com");
        
        
        



       
        System.out.println();
        System.out.println(cust.toString());
        System.out.println(emp.toString());
        
        
    }
}