package OOPSAssignment1;

import java.time.LocalDate;



public class Person {



   private int pid;
    private String name;
    private String address;
    private LocalDate dob;
    
    
    public int getPid() {
        return pid;
    }
    public void setPid(int pid) {
        this.pid = pid;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;
    }
    public LocalDate getDob() {
        return dob;
    }
    public void setDob(LocalDate dob) {
        this.dob = dob;
    }
    
    public Person(int pid, String name, String address, LocalDate dob) {
        this.pid = pid;
        this.name = name;
        this.address = address;
        this.dob = dob;
    }
    @Override
    public String toString() {
        return "Person [pid=" + pid + ", name=" + name + ", address=" + address + ", dob=" + dob + "]";
    }
    
    
    
}