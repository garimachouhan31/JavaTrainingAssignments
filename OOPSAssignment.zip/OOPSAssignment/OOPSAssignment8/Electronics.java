package OOPSAssignment8;

public class Electronics {
    
    int id;
    String semiType;
    String dateOfManufacturing;
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getSemiType() {
        return semiType;
    }
    public void setSemiType(String semiType) {
        this.semiType = semiType;
    }
    public String getDateOfManufacturing() {
        return dateOfManufacturing;
    }
    public void setDateOfManufacturing(String dateOfManufacturing) {
        this.dateOfManufacturing = dateOfManufacturing;
    }
    @Override
    public String toString() {
        return "Electronics [id=" + id + ", semiType=" + semiType + ", dateOfManufacturing=" + dateOfManufacturing
                + "]";
    }
    protected Electronics(int id, String semiType, String dateOfManufacturing) {
        super();
        this.id = id;
        this.semiType = semiType;
        this.dateOfManufacturing = dateOfManufacturing;
    }
    
    



}
