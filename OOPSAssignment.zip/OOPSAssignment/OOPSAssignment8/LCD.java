package OOPSAssignment8;

public class LCD  extends Electronics{



	   protected LCD(int id, String semiType, String dateOfManufacturing) {
	        super(id, semiType, dateOfManufacturing);
	        // TODO Auto-generated constructor stub
	    }



	}