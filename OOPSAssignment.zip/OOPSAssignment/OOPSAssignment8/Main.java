package OOPSAssignment8;

public class Main {
    
    
    public static void main(String[] args) {
        
        Electronics ec = new Electronics(1, " Ic", " 12-1-2022");
        Electronics el= new Laptop(2, " battery", " 22-2-2021");
        Electronics el1 = new LCD(3, " chip", " 15-3-2019");
        Electronics em = new Mobile(4, " memory", " 2-4-2020");
        
        System.out.println(ec);
        System.out.println(el);
        System.out.println(el1);
        System.out.println(em);
    }



}