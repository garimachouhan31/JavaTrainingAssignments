/*An Array Contain different numbers you have to find how many are even, odd, perfect and 
prime*/
package ArrayAssignments;

import java.io.*;

class EvenOrOdd5{

 static void CountingEvenOdd(int arr[], int arr_size)
 {
     int even_count = 0;
     int odd_count = 0;

    
     for (int i = 0; i < arr_size; i++) {
          
          
         if ((arr[i] & 1) == 1)
             odd_count++;
         else
             even_count++;
     }

     System.out.println(" even numbers = "+ even_count + " odd numbers = " + odd_count);
 }


 public static void main(String[] args)
 {
     int arr[] = { 2, 3, 4, 5, 6, 7, 8, 9, 10 };
     int n = arr.length;
        
     
     CountingEvenOdd(arr, n);
 }
}