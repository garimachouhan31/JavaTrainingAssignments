package ArrayAssignments;
import java.util.Arrays;
class ThirdLargestNumber1 {
   public static void main(String args[]){

   int array[] = {10, 20, 30, 40, 50,60};
   
   Arrays.sort(array);
   
//   for(int i = 0; i<array.length; i++ )
  //  {
    //  for(int j = i+1; j<array.length; j++)
      //   {
           
         //if(array[i]>array[j]){
           // temp = array[i];
            //array[i] = array[j];
           // array[j] = temp;
        // }
    //  }
 //  }
   System.out.println("Third largest number is:: "+array[array.length-3]);
   }
}

