package ArrayAssignments;

public class VowelConsonent8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int vowCount = 0, conCount = 0;  
         
	      
	       char []a=new char[]{'h','e','l','l','o','g','u','y','s'};
	          
	         for(int i = 0; i < a.length; i++) 
	         {  
	             
	            if(a[i] == 'a' || a[i] == 'e' || a[i] == 'i' || a[i] == 'o' ||a[i] == 'u')
	            {  
	              System.out.println("vowel");
	                System.out.println(a[i]); 
	                vowCount++;  
	            }  
	             
	            else if(a[i] >= 'a' && a[i]<='z')
	            {  
	              System.out.println("consonent");    
	               System.out.println(a[i]);   
	                conCount++;  
	            }  
	        }  
	        System.out.println("No of vowels:->" + vowCount);  
	        System.out.println("No of consonants:-> " + conCount);  
	}

}
