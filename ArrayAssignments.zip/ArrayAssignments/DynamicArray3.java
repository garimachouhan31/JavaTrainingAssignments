package ArrayAssignments;

public class DynamicArray3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int array[] = new int[6];  
		 
		array[0] = 34;  
		array[1] = 90;  
		array[2] = 12;  
		array[3] = 22;  
		array[4] = 9;  
		array[5] = 27;  
		System.out.print("Elements of Array are: ");  
		 
		for(int i=0; i< array.length ; i++)   
		{  
		System.out.print(array[i] +" ");  
		}  
	}

}
