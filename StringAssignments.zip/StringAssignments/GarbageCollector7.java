package StringAssignments;

public class GarbageCollector7{  
	 public void finalize()
	 {
		 System.out.println("object is garbage collector");
		 }  
	 public static void main(String args[]){  
		 GarbageCollector7 s1=new GarbageCollector7();  
		 GarbageCollector7 s2=new GarbageCollector7();  
	  s1=null;  
	  s2=null;  
	  System.gc();  
	 }  
	}  