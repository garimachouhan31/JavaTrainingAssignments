package StringAssignments;




import java.util.Scanner;

public class Assignment1 {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter String");
		String str1 = sc.nextLine();
		System.out.println("Enter the second String");
		String str2 = sc.nextLine();
		System.out.println("Enter Index Number");
		int ind = sc.nextInt();


		StringBuffer sb=new StringBuffer(str1);
		sb.insert(ind, str2);
		System.out.println(sb);}

}


